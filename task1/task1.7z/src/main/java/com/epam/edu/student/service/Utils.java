package com.epam.edu.student.service;

public interface Utils {
int getRandom();
}
